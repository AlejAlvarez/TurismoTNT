import ApolloClient from 'apollo-boost';
import {gql} from 'apollo-boost';
import DEFAULT_IP from '@resources/IPConfig';

const client = new ApolloClient({
  uri: `http://${DEFAULT_IP}:8080/v1/graphql`,
});

export default function MensajesService() {

  const getMessages = async () => {
    const response = await client.query({
      query: gql `
        query MyQuery {
          mensajes(where: {timestamp: {_lte: "now() - interval '1 day'"}}) {
            id
            mensaje
            timestamp
            usuario {
              id
              apellido
              nombre
            }
          }
        }
      `,
    });
    return response.data.mensajes;    
  }

}